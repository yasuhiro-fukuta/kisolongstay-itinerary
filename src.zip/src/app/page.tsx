import MapItineraryBuilder from "@/components/MapItineraryBuilder";

export default function Page() {
  return <MapItineraryBuilder />;
}
